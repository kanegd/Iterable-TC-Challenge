package com.example.garrettkaneiterabletcchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.iterable.iterableapi.IterableApi;
import com.iterable.iterableapi.IterableConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //initialize UI
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //debugging output
        TextView output = findViewById(R.id.Output);
        output.setText("initialized");

        //initialize Iterable SDK
        String userEmail = "twistedcircuits99@gmail.com";
        IterableConfig config = new IterableConfig.Builder().build();
        IterableApi.initialize(getApplicationContext(),"349dcc9373c74c6699c5d1204a271695",config);
        IterableApi APIinstance = IterableApi.getInstance();
        APIinstance.setEmail(userEmail);
        output.append(" | API Initialized");

        Button updateProfile = findViewById(R.id.UpdateProfile);
        updateProfile.setOnClickListener(v -> {
            try {
                sendMessage(v,userEmail,APIinstance);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }
    public void sendMessage(View view, String email,IterableApi APIinstance) throws JSONException {
        //execute on button press
        TextView output = findViewById(R.id.Output);
        output.append(" | Button Pressed");

        JSONObject userData = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("firstName", "Garrett");
        data.put("isRegisteredUser", true);
        data.put("SA_User_Test_Key", "completed");
        userData.put("email", email);
        userData.put("dataFields", data);
        output.append(userData.toString());
        APIinstance.updateUser(userData);
        output.append(" | Finished");
    }
}